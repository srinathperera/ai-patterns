# Cluster 0

def norm_newline(s):
    return s.replace('\r\n', '\n').replace('\r', '\n')

