# Cluster 157

def mkdirs(paths):
    if isinstance(paths, str):
        mkdir(paths)
    else:
        for path in paths:
            mkdir(path)

def mkdir(path):
    if not os.path.exists(path):
        os.makedirs(path)

