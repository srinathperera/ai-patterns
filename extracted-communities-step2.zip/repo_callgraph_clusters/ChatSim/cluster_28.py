# Cluster 28

def evaluate(model_paths):
    full_dict = {}
    per_view_dict = {}
    full_dict_polytopeonly = {}
    per_view_dict_polytopeonly = {}
    print('')
    for scene_dir in model_paths:
        try:
            print('Scene:', scene_dir)
            full_dict[scene_dir] = {}
            per_view_dict[scene_dir] = {}
            full_dict_polytopeonly[scene_dir] = {}
            per_view_dict_polytopeonly[scene_dir] = {}
            test_dir = Path(scene_dir) / 'test'
            train_dir = Path(scene_dir) / 'train'
            evaulation = {'test': test_dir, 'train': train_dir}
            for split, split_dir in evaulation.items():
                if not os.path.exists(split_dir):
                    continue
                for method in os.listdir(split_dir):
                    print('Method:', method)
                    full_dict[scene_dir][method] = {}
                    per_view_dict[scene_dir][method] = {}
                    full_dict_polytopeonly[scene_dir][method] = {}
                    per_view_dict_polytopeonly[scene_dir][method] = {}
                    method_dir = split_dir / method
                    gt_dir = method_dir / 'gt'
                    renders_dir = method_dir / 'renders'
                    subdirs = [d for d in os.listdir(gt_dir) if os.path.isdir(gt_dir / d)]
                    if len(subdirs) == 0:
                        renders, gts, image_names = readImages(renders_dir, gt_dir)
                        ssims = []
                        psnrs = []
                        lpipss = []
                        for idx in tqdm(range(len(renders)), desc='Metric evaluation progress'):
                            ssims.append(ssim(renders[idx], gts[idx]))
                            psnrs.append(psnr(renders[idx], gts[idx]))
                            lpipss.append(lpips(renders[idx], gts[idx], net_type='vgg'))
                        print('  SSIM : {:>12.7f}'.format(torch.tensor(ssims).mean(), '.5'))
                        print('  PSNR : {:>12.7f}'.format(torch.tensor(psnrs).mean(), '.5'))
                        print('  LPIPS: {:>12.7f}'.format(torch.tensor(lpipss).mean(), '.5'))
                        print('')
                        full_dict[scene_dir][method].update({'SSIM': torch.tensor(ssims).mean().item(), 'PSNR': torch.tensor(psnrs).mean().item(), 'LPIPS': torch.tensor(lpipss).mean().item()})
                        per_view_dict[scene_dir][method].update({'SSIM': {name: ssim for ssim, name in zip(torch.tensor(ssims).tolist(), image_names)}, 'PSNR': {name: psnr for psnr, name in zip(torch.tensor(psnrs).tolist(), image_names)}, 'LPIPS': {name: lp for lp, name in zip(torch.tensor(lpipss).tolist(), image_names)}})
                    else:
                        for subdir in subdirs:
                            print(' Subdir:', subdir)
                            renders, gts, image_names = readImages(renders_dir / subdir, gt_dir / subdir)
                            ssims = []
                            psnrs = []
                            lpipss = []
                            for idx in tqdm(range(len(renders)), desc='Metric evaluation progress'):
                                ssims.append(ssim(renders[idx], gts[idx]))
                                psnrs.append(psnr(renders[idx], gts[idx]))
                                lpipss.append(lpips(renders[idx], gts[idx], net_type='vgg'))
                            print('  SSIM : {:>12.7f}'.format(torch.tensor(ssims).mean(), '.5'))
                            print('  PSNR : {:>12.7f}'.format(torch.tensor(psnrs).mean(), '.5'))
                            print('  LPIPS: {:>12.7f}'.format(torch.tensor(lpipss).mean(), '.5'))
                            print('')
                            full_dict[scene_dir][method][subdir] = {}
                            per_view_dict[scene_dir][method][subdir] = {}
                            full_dict[scene_dir][method][subdir].update({'SSIM': torch.tensor(ssims).mean().item(), 'PSNR': torch.tensor(psnrs).mean().item(), 'LPIPS': torch.tensor(lpipss).mean().item()})
                            per_view_dict[scene_dir][method][subdir].update({'SSIM': {name: ssim for ssim, name in zip(torch.tensor(ssims).tolist(), image_names)}, 'PSNR': {name: psnr for psnr, name in zip(torch.tensor(psnrs).tolist(), image_names)}, 'LPIPS': {name: lp for lp, name in zip(torch.tensor(lpipss).tolist(), image_names)}})
                    with open(scene_dir + f'/{split}_results.json', 'w') as fp:
                        json.dump(full_dict[scene_dir], fp, indent=True)
                    with open(scene_dir + f'/{split}_per_view.json', 'w') as fp:
                        json.dump(per_view_dict[scene_dir], fp, indent=True)
        except Exception as e:
            print('Unable to compute metrics for model', scene_dir, ':', e)

def readImages(renders_dir, gt_dir):
    renders = []
    gts = []
    image_names = []
    for fname in os.listdir(renders_dir):
        render = Image.open(renders_dir / fname)
        gt = Image.open(gt_dir / fname)
        renders.append(tf.to_tensor(render).unsqueeze(0)[:, :3, :, :].cuda())
        gts.append(tf.to_tensor(gt).unsqueeze(0)[:, :3, :, :].cuda())
        image_names.append(fname)
    return (renders, gts, image_names)

