# Cluster 48

def main_worker(rank, config):
    if 'local_rank' not in config:
        config['local_rank'] = config['global_rank'] = rank
    if config['distributed']:
        torch.cuda.set_device(int(config['local_rank']))
        torch.distributed.init_process_group(backend='nccl', init_method=config['init_method'], world_size=config['world_size'], rank=config['global_rank'], group_name='mtorch')
        print('using GPU {}-{} for training'.format(int(config['global_rank']), int(config['local_rank'])))
    config['save_dir'] = os.path.join(config['save_dir'], '{}_{}'.format(config['model'], os.path.basename(args.config).split('.')[0]))
    if torch.cuda.is_available():
        config['device'] = torch.device('cuda:{}'.format(config['local_rank']))
    else:
        config['device'] = 'cpu'
    if not config['distributed'] or config['global_rank'] == 0:
        os.makedirs(config['save_dir'], exist_ok=True)
        config_path = os.path.join(config['save_dir'], config['config'].split('/')[-1])
        if not os.path.isfile(config_path):
            copyfile(config['config'], config_path)
        print('[**] create folder {}'.format(config['save_dir']))
    trainer = Trainer(config, debug=args.exam)
    trainer.train()

