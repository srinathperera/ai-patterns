# Cluster 52

def run_export(model_type: str, checkpoint: str, output: str, opset: int, return_single_mask: bool, gelu_approximate: bool=False, use_stability_score: bool=False, return_extra_metrics=False):
    print('Loading model...')
    sam = sam_model_registry[model_type](checkpoint=checkpoint)
    onnx_model = SamOnnxModel(model=sam, return_single_mask=return_single_mask, use_stability_score=use_stability_score, return_extra_metrics=return_extra_metrics)
    if gelu_approximate:
        for n, m in onnx_model.named_modules():
            if isinstance(m, torch.nn.GELU):
                m.approximate = 'tanh'
    dynamic_axes = {'point_coords': {1: 'num_points'}, 'point_labels': {1: 'num_points'}}
    embed_dim = sam.prompt_encoder.embed_dim
    embed_size = sam.prompt_encoder.image_embedding_size
    mask_input_size = [4 * x for x in embed_size]
    dummy_inputs = {'image_embeddings': torch.randn(1, embed_dim, *embed_size, dtype=torch.float), 'point_coords': torch.randint(low=0, high=1024, size=(1, 5, 2), dtype=torch.float), 'point_labels': torch.randint(low=0, high=4, size=(1, 5), dtype=torch.float), 'mask_input': torch.randn(1, 1, *mask_input_size, dtype=torch.float), 'has_mask_input': torch.tensor([1], dtype=torch.float), 'orig_im_size': torch.tensor([1500, 2250], dtype=torch.float)}
    _ = onnx_model(**dummy_inputs)
    output_names = ['masks', 'iou_predictions', 'low_res_masks']
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=torch.jit.TracerWarning)
        warnings.filterwarnings('ignore', category=UserWarning)
        with open(output, 'wb') as f:
            print(f'Exporing onnx model to {output}...')
            torch.onnx.export(onnx_model, tuple(dummy_inputs.values()), f, export_params=True, verbose=False, opset_version=opset, do_constant_folding=True, input_names=list(dummy_inputs.keys()), output_names=output_names, dynamic_axes=dynamic_axes)
    if onnxruntime_exists:
        ort_inputs = {k: to_numpy(v) for k, v in dummy_inputs.items()}
        ort_session = onnxruntime.InferenceSession(output)
        _ = ort_session.run(None, ort_inputs)
        print('Model has successfully been run with ONNXRuntime.')

